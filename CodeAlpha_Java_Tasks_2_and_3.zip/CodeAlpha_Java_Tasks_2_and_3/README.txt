CODEALPHA JAVA INTERNSHIP - TASK 2 AND TASK 3

This package contains two separate Java console projects:
1. Task_2_Stock_Trading_Platform
2. Task_3_AI_Chatbot

Each project has its own Main.java and README.txt.
Compile and run each project separately by following its README.

Suggested GitHub repository name:
CodeAlpha_ProjectName

You can create two separate GitHub repositories, or put both folders into one
repository if your internship submission instructions allow it.
