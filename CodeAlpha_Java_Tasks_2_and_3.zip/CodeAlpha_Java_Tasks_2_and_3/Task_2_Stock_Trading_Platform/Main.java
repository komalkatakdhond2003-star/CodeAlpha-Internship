import java.util.*;

class Stock {
    private final String symbol;
    private final String companyName;
    private final double price;

    public Stock(String symbol, String companyName, double price) {
        this.symbol = symbol;
        this.companyName = companyName;
        this.price = price;
    }

    public String getSymbol() { return symbol; }
    public String getCompanyName() { return companyName; }
    public double getPrice() { return price; }
}

class Transaction {
    private final String type;
    private final String symbol;
    private final int quantity;
    private final double price;

    public Transaction(String type, String symbol, int quantity, double price) {
        this.type = type;
        this.symbol = symbol;
        this.quantity = quantity;
        this.price = price;
    }

    public void display() {
        System.out.printf("%-6s %-8s Quantity: %-5d Price: Rs. %.2f Total: Rs. %.2f%n",
                type, symbol, quantity, price, quantity * price);
    }
}

class Portfolio {
    private double cashBalance = 100000.00;
    private final Map<String, Integer> holdings = new LinkedHashMap<>();
    private final List<Transaction> history = new ArrayList<>();

    public boolean buy(Stock stock, int quantity) {
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than zero.");
            return false;
        }
        double cost = stock.getPrice() * quantity;
        if (cost > cashBalance) {
            System.out.println("Insufficient balance. Available: Rs. " +
                    String.format("%.2f", cashBalance));
            return false;
        }
        cashBalance -= cost;
        holdings.put(stock.getSymbol(),
                holdings.getOrDefault(stock.getSymbol(), 0) + quantity);
        history.add(new Transaction("BUY", stock.getSymbol(), quantity, stock.getPrice()));
        System.out.println("Stock purchased successfully.");
        return true;
    }

    public boolean sell(Stock stock, int quantity) {
        int owned = holdings.getOrDefault(stock.getSymbol(), 0);
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than zero.");
            return false;
        }
        if (quantity > owned) {
            System.out.println("You do not have enough shares to sell. Owned: " + owned);
            return false;
        }
        cashBalance += stock.getPrice() * quantity;
        int remaining = owned - quantity;
        if (remaining == 0) holdings.remove(stock.getSymbol());
        else holdings.put(stock.getSymbol(), remaining);
        history.add(new Transaction("SELL", stock.getSymbol(), quantity, stock.getPrice()));
        System.out.println("Stock sold successfully.");
        return true;
    }

    public void showPortfolio(Map<String, Stock> market) {
        System.out.println("\n========== YOUR PORTFOLIO ==========");
        System.out.printf("Available cash: Rs. %.2f%n", cashBalance);
        if (holdings.isEmpty()) {
            System.out.println("No stocks owned yet.");
        } else {
            double investmentValue = 0;
            System.out.printf("%-10s %-10s %-15s%n", "Symbol", "Quantity", "Market Value");
            for (Map.Entry<String, Integer> item : holdings.entrySet()) {
                Stock stock = market.get(item.getKey());
                double value = stock.getPrice() * item.getValue();
                investmentValue += value;
                System.out.printf("%-10s %-10d Rs. %-12.2f%n",
                        item.getKey(), item.getValue(), value);
            }
            System.out.printf("Total stock value: Rs. %.2f%n", investmentValue);
            System.out.printf("Total portfolio value: Rs. %.2f%n",
                    cashBalance + investmentValue);
        }
    }

    public void showHistory() {
        System.out.println("\n========== TRANSACTION HISTORY ==========");
        if (history.isEmpty()) {
            System.out.println("No transactions yet.");
            return;
        }
        for (Transaction transaction : history) transaction.display();
    }
}

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Map<String, Stock> market = new LinkedHashMap<>();

    public static void main(String[] args) {
        market.put("TCS", new Stock("TCS", "Tata Consultancy Services", 3850.00));
        market.put("INFY", new Stock("INFY", "Infosys", 1750.00));
        market.put("RELI", new Stock("RELI", "Reliance Industries", 1420.00));
        market.put("WIPRO", new Stock("WIPRO", "Wipro", 560.00));
        market.put("HDFC", new Stock("HDFC", "HDFC Bank", 1680.00));

        Portfolio portfolio = new Portfolio();
        System.out.println("====================================");
        System.out.println("       STOCK TRADING PLATFORM");
        System.out.println("        SIMULATION PROJECT");
        System.out.println("====================================");

        while (true) {
            System.out.println("\n1. View Market Data");
            System.out.println("2. Buy Stock");
            System.out.println("3. Sell Stock");
            System.out.println("4. View Portfolio");
            System.out.println("5. View Transaction History");
            System.out.println("6. Exit");
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    showMarket();
                    break;
                case 2:
                    trade(portfolio, true);
                    break;
                case 3:
                    trade(portfolio, false);
                    break;
                case 4:
                    portfolio.showPortfolio(market);
                    break;
                case 5:
                    portfolio.showHistory();
                    break;
                case 6:
                    System.out.println("Thank you for using the Stock Trading Platform!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please select 1 to 6.");
            }
        }
    }

    private static void showMarket() {
        System.out.println("\n========== MARKET DATA (SIMULATED) ==========");
        System.out.printf("%-10s %-32s %s%n", "Symbol", "Company", "Price");
        for (Stock stock : market.values()) {
            System.out.printf("%-10s %-32s Rs. %.2f%n",
                    stock.getSymbol(), stock.getCompanyName(), stock.getPrice());
        }
        System.out.println("Note: Prices are sample values, not live market data.");
    }

    private static void trade(Portfolio portfolio, boolean isBuy) {
        showMarket();
        System.out.print("Enter stock symbol: ");
        String symbol = scanner.nextLine().trim().toUpperCase();
        Stock stock = market.get(symbol);
        if (stock == null) {
            System.out.println("Stock symbol not found.");
            return;
        }
        int quantity = readInt("Enter quantity: ");
        if (isBuy) portfolio.buy(stock, quantity);
        else portfolio.sell(stock, quantity);
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }
}
