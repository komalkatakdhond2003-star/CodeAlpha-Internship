TASK 2: STOCK TRADING PLATFORM
Language: Java
Type: Console-based simulation

FEATURES
- Displays sample market prices for TCS, Infosys, Reliance, Wipro and HDFC Bank.
- Allows the user to buy and sell shares.
- Checks available cash and owned share quantity.
- Tracks cash balance, stock holdings and portfolio value.
- Displays transaction history.
- Uses classes, objects, encapsulation, ArrayList and HashMap/Map.

HOW TO RUN
1. Install JDK.
2. Open this folder in VS Code or a terminal.
3. Compile: javac Main.java
4. Run: java Main

NOTE
This is an educational simulation. Stock prices are fixed sample values and are
not live financial data. No real money or real trading is involved.
