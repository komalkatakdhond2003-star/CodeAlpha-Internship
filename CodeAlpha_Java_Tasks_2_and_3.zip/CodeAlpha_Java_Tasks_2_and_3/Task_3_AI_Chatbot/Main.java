import java.util.*;

class Chatbot {
    private final Map<String, String> responses = new LinkedHashMap<>();

    public Chatbot() {
        responses.put("hello", "Hello! Welcome. How can I help you?");
        responses.put("hi", "Hi there! What would you like to know?");
        responses.put("your name", "I am CodeAlpha Java Assistant, a simple rule-based chatbot.");
        responses.put("help", "I can answer questions about Java, programming, internships and this project.");
        responses.put("java", "Java is an object-oriented, platform-independent programming language.");
        responses.put("oops", "OOP stands for Object-Oriented Programming. Its main concepts are encapsulation, inheritance, polymorphism and abstraction.");
        responses.put("internship", "An internship gives students practical experience and helps them develop job-related skills.");
        responses.put("project", "This chatbot uses basic NLP steps such as lowercasing, cleaning punctuation and keyword matching.");
        responses.put("thank", "You're welcome! Happy to help.");
        responses.put("bye", "Goodbye! Have a great day.");
    }

    public String getResponse(String input) {
        String cleaned = normalize(input);

        if (cleaned.isEmpty()) {
            return "Please type a message so I can help you.";
        }

        // Simple intent/keyword matching (rule-based NLP approach).
        if (containsAny(cleaned, "good morning", "good afternoon", "good evening")) {
            return "Hello! Hope you are having a good day.";
        }
        if (containsAny(cleaned, "how are you", "how are u")) {
            return "I am doing well. Thank you for asking!";
        }
        if (containsAny(cleaned, "what can you do", "your features")) {
            return "I can respond to greetings and basic questions about Java, OOP, internships and this project.";
        }

        // Match known FAQ phrases or important words.
        for (Map.Entry<String, String> item : responses.entrySet()) {
            if (cleaned.contains(item.getKey())) {
                return item.getValue();
            }
        }

        return "Sorry, I don't know that yet. Try asking about Java, OOP, internship, project or help.";
    }

    private String normalize(String text) {
        return text.toLowerCase(Locale.ROOT)
                   .replaceAll("[^a-z0-9\\s]", " ")
                   .replaceAll("\\s+", " ")
                   .trim();
    }

    private boolean containsAny(String text, String... phrases) {
        for (String phrase : phrases) {
            if (text.contains(phrase)) return true;
        }
        return false;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Chatbot bot = new Chatbot();

        System.out.println("====================================");
        System.out.println("       CODEALPHA AI CHATBOT");
        System.out.println("====================================");
        System.out.println("Bot: Hello! Ask me something.");
        System.out.println("Bot: Type 'bye' to end the conversation.");

        while (true) {
            System.out.print("\nYou: ");
            String message = scanner.nextLine();
            String reply = bot.getResponse(message);
            System.out.println("Bot: " + reply);

            String normalized = message.toLowerCase(Locale.ROOT).trim();
            if (normalized.equals("bye") || normalized.equals("goodbye")) {
                break;
            }
        }

        System.out.println("\nChat session ended.");
        scanner.close();
    }
}
