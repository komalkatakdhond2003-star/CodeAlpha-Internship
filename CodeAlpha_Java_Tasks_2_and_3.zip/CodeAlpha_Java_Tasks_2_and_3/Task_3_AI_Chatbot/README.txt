TASK 3: ARTIFICIAL INTELLIGENCE CHATBOT
Language: Java
Type: Console-based rule-based chatbot

FEATURES
- Interactive text conversation.
- Handles greetings and common questions.
- Includes FAQ responses about Java, OOP, internships and the project.
- Uses basic NLP preprocessing: lowercase conversion, punctuation removal,
  whitespace cleanup and keyword/phrase matching.
- Uses rule-based response logic and can be extended with more FAQs.

HOW TO RUN
1. Install JDK.
2. Open this folder in VS Code or a terminal.
3. Compile: javac Main.java
4. Run: java Main

NOTE
This is a beginner-level rule-based chatbot. It does not train a machine-learning
model or use an external NLP service. The task permits rule-based answers.
